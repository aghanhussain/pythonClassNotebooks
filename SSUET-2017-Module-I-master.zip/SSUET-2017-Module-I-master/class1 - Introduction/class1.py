fname = "Muhammad"
lastName ="Qasim"
fullName = fname +" "+lastName
age = 23
gender = "Male"

t1= str(1)+ str(1)

print("SSUET A.I Students Card")
print("Studnet Name: ",fullName)
print("Age: ",age," Gender: ",gender)
print(5+7)

print(5+8*2/2+2*20)

print("SSUET A.I Student \nStudent Name: "+fullName+"\nAge: "+str(age))

print(100 + 10)
print(100 - 10)
print( 100 * 10)
print(100 / 10)
print("100"+"10")
print(str(100)+str(10))
print(100%10)
print(100^10)
print(100**10)
print(36//6)