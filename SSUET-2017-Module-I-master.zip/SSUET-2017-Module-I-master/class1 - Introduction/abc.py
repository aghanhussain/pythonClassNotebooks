print("Pakistan zinda bad")
print("We are pakistani")
print("We always love with our country")
print("P...............")