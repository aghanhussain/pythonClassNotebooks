# SSUET-2017-Module-I

## Class1 Introduction to Course
- Road map (course outline)
- Python Basics
## Class2 Five Videos
Transcript: The 5 questions data science answers
1. Question 1: Is this A or B? uses classification algorithms
2. Question 2: Is this weird? uses anomaly detection algorithms
3. Question 3: How much? or How many? uses regression algorithms
4. Question 4: How is this organized? uses clustering algorithms
5. Question 5: What should I do now? uses reinforcement learning algorithms
### Data Science, Operation team, Developer, DevOpe DataDevOpe
### Microservices
## Class3 Git Version Control System
- Basics
- Branches
- Remote
## Class4 Smater Way to learn python
- Variables
- Operation, oprands, operators
- print
## Class5 (Dictionary, if_else_elif, and_or_not_in, for loop)
- if
- else
- elif
- and, or, not, in
- for loop
- dictionary
	- .keys()
	- .values()
	- .items()
## Class6 (Functions, loop, input)
- Functions
    - Required Arguments
    - Optional Arguments
    - Return
    - Non Return
    - Defualt Arguments
    - postional Arguments
    - KeyWord Arguments
    - Argument with List
    - Argument with Dictionary 
    - pre defineFunctions
    - User defineFunctions
- Loop
    - for
    - while
    - do while
- input
## Class7 (Assignment 1 to 6)
## Class8 (OOP)
- class
- instance/object
- method
- attributes/properties
- inheritance
- polymorphisim
	- overloading
	- over riding
- Encupsolation
- Abstract Class
- public/private
	- method
	- attributes