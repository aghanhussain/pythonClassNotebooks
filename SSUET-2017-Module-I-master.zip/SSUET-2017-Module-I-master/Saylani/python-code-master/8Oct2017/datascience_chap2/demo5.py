myList = [True, 0, { 3 },""]

result = any(myList)

print(result)