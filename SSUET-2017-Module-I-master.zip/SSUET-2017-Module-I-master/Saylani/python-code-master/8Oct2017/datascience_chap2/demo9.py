x = [-4,1,-2,3]

#a = lambda (a)

y = sorted(x,key=lambda c:c*2)
print(x)
print(y)


d = lambda c:c*2
print(d(-4))
print(d(1))
print(d(-2))
print(d(3))
