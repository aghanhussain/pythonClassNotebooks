from collections import Counter
document = "That the quick brown fox jumps quick over fox the lazy dog fox"

c = Counter(document.split())
print(c)

if "a":
    print("Hello")
else:
    print("else")