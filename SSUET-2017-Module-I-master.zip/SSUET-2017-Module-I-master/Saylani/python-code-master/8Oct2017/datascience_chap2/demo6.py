x = [4,1,2,3]
#y = sorted(x) # is [1,2,3,4], x is unchanged
x.sort()
print(x)
#print(y)