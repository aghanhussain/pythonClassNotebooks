x = range(10)
y = list(x)
print(x)
print(y)
for z in x:
    print(z)
