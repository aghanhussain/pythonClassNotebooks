
a = lambda b:b*2 +4*b

print(a)
print(a(2))
