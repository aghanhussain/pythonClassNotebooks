x = [-4,1,-2,3]
y = sorted(x,key=abs)

print(x)
print(y)