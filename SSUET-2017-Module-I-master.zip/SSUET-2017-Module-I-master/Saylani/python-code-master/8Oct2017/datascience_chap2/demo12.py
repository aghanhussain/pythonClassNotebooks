even_numbers = [x for x in range(5) if x%2 == 0]
print(even_numbers)

zeroes = [0 for _ in even_numbers]
print(zeroes)

ab = [4,6,8,25,14]
def abc (a):
    print(a)

even_numbers1 = [x for x in range(15) if abc(x)]
print(even_numbers1)

