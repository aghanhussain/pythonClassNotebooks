myList = [True, 1, { 3 },"a"]

result = all(myList)

print(result)