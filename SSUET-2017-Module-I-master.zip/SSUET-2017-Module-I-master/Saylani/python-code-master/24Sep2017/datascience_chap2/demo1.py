two_plus_three = 2 + \
3
print(two_plus_three)

name =" Muhammad " \
      "Qasim"
print(name)

details ="""" Q
Muhammd Qasim
Muhammd Aslam
"""

print(details)