print(all(["",True, 1, { 3 }]))

