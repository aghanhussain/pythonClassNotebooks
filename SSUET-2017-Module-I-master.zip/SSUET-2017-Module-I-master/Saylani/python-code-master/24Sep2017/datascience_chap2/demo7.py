v = [45,47]

if v:
    print("its true")
else:
    print("its false")