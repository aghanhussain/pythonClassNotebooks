x = 11
y = 21
parity = "even" if x % 2 == 0 else "odd"
print(parity)

parity2 = "even" if x % 2 == 0 else "y even" if y % 2 == 0 else "y odd"
print(parity2)