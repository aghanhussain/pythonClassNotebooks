x = sorted([-4,1,-2,3], key=abs, reverse=True)
print(x)