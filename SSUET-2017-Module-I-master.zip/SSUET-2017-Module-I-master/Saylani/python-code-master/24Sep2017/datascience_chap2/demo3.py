mylist = (2,94,14)

a, b, c = mylist

print(mylist)
print(a)
print(b)
print(c)