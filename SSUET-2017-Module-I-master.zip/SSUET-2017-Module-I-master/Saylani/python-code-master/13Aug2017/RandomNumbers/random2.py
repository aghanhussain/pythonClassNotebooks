from random import randint
num = 0
mylist = []
for val in range(0,10):
    num = randint(1,15)
    mylist.append(num)
    print(num)

print(mylist)

val = 6;
val in mylist