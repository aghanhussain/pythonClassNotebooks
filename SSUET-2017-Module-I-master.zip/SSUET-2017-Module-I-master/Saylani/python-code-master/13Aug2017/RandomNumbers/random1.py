from random import randint


num = randint(1,15)
print(num)