play = "yes"

print(play is "yes")