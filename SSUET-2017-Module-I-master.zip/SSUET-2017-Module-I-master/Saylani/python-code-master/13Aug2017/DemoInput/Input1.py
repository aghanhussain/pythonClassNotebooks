message = input("Enter your name ")
print("Hello "+message+"!")