age = input("How old are you? ")
age = int(age)
print(age)
if age>18:
    print("Here is yor CNIC")
else :
    print("Grow up")