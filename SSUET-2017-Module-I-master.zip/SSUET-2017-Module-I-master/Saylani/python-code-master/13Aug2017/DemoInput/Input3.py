age = int(input("How old are you? "))
print(age)
if age>18:
    print("Here is yor CNIC")
else :
    print("Grow up")