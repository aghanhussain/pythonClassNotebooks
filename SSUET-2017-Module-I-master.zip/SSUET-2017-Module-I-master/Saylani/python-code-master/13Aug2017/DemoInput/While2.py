current_number = int(input("Enter number "))
num = 0

while num < current_number:
    print(num)
    num += 1

print("Final",num)
