num = int(input("Enter your number"))
if num % 2 == 0:
    print("The number "+str(num)+" even")
else:
    print("The number " + str(num) + " odd")