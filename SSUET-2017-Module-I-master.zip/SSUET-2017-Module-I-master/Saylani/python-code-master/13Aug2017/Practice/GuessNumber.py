# 1) generate random number
# 2) user guess number with input
# 3) if number match you win
    # else you lose
# 4) if user input is incorrect
    # give him 3 chance

# 5) after win or lose ask user
    # do you want to continue
    # if user say yes Generate
    # New Random number
    # start from Point 1 again