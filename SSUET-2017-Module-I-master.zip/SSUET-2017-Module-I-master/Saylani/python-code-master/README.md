# python-code
Python Code for AI class
