def multiply(x, y):
    return x * y

a = multiply(1,2)
print(a)
b = multiply(a,3)
print(b)
c = multiply(b,4)
print(c)