def double(x):
    return 2 * x

#print(double(4))
xs = [1, 2, 3, 4]
xs2 = []
for x3 in xs:
    print(x3*2)
    #xs2.append(double(x3))


