documents = ["hello","world","new","that","working"]

for i, document in enumerate(documents):
    print("I = "+str(i)+" doc = "+document)