def acceptArray(*a):
    print(a)
    print(a[0])
    print(a[4])

acceptArray(3,5,7,8,9)