list1 = ['a', 'b','d', 'c',]
list2 = [1, 2, 3,4,5,6]
print(list(zip(list1, list2)))