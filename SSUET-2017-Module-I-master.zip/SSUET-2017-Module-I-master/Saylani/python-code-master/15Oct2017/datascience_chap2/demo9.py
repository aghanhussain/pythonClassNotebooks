def double(x):
    return 2 * x


xs = [1, 2, 3, 4]
xs2 = map(double,xs)

#print(list(xs2))

for a in xs2:
    print(a)

print("test")
for a in xs2:
    print(a)




