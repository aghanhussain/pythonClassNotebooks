def myfunction(x):
    return x * 3

def doubler(f):
    return 4 + f(6)

print(doubler(myfunction))
