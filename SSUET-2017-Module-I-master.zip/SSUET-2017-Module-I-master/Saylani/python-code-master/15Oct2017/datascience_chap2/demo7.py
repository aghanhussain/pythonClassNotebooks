import functools
def double(x):
    return 2 * x

#print(double(4))
xs = [1, 2, 3, 4]
xs2 = []
for x3 in xs:
    #print(double(x3))
    xs2.append(double(x3))

print(xs2)


