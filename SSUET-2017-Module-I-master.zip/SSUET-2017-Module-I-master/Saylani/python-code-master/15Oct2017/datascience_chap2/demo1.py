def exp(base, power):
    return base ** power

def two_to_the(power):
    return exp(2, power)

print(exp(2,4))
print(exp(2,5))
print(exp(2,6))

print(two_to_the(8))