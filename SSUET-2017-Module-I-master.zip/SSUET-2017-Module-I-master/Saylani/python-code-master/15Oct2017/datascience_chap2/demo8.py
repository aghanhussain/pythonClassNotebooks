def double(x):
    return 2 * x

#print(double(4))
xs = [1, 2, 3, 4]
xs2 = [double(x3) for x3 in xs]

print(xs2)


