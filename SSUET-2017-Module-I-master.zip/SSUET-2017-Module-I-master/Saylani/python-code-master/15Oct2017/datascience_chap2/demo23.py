#Not allowed
#def acceptArray(**b,a):
def acceptArray(**b):
    print(b)

acceptArray(hello="work",new="test")