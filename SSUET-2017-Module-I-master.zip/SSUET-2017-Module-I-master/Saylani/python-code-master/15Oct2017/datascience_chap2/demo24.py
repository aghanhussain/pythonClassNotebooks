def acceptArray(a,**b):
    print(a)
    print(b)

acceptArray(34,hello="work",new="test")
acceptArray(hello="work",new="test",a=23)
#acceptArray(hello="work",new="test",23)