def acceptArray(**b):
    print(b)

acceptArray()