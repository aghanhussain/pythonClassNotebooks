dimensions = tuple(val**2 for val in range(1,11))
print(dimensions)

