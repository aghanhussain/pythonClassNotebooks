dimensions = tuple(range(1,11))
print(dimensions)
for d in dimensions:
    print(d)


