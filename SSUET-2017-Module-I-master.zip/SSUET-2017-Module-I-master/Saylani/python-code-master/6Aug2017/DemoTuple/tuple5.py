dimensions = (200,500)
print(dimensions)
dimensions = (300,500)
print(dimensions)

