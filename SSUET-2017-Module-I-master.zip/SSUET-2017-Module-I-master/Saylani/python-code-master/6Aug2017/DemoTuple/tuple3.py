dimensions = (200, 50)
print(dimensions)
dimensions[1] = 45
print(dimensions)


