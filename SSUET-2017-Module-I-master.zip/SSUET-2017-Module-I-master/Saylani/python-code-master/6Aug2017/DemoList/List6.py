players = ['charles', 'martina', 'michael', 'florence', 'eli']
fewPlayers = players[1:3]
print(fewPlayers)
fewPlayers[0] = "Hello"
print(fewPlayers)
print(players)