players = ['charles', 'martina', 'michael',
           'florence', 'eli',"1",
           "2","3","4"]
print(players)
print(players[-3])
fewPlayers = players[-3:-7:-1]
print(fewPlayers)

