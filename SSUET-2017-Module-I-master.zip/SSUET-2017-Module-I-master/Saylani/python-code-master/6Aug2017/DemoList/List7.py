players = ['charles', 'martina', 'michael',
           'florence', 'eli',"asdf",
           "asdfa","asdfadf","astest"]
fewPlayers = players[4:7]
print(fewPlayers)
print(players)