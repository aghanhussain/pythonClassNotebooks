players = ['charles', 'martina', 'michael',
           'florence', 'eli',"1",
           "2","3","4"]
fewPlayers = players[1:6:2]
print(fewPlayers)
print(players)