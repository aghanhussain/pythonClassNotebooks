values = [val for val in range(1,11)]
values2 = [val for val in range(1,11,2)]
squares = [value**2+2 for value in range(1,11)]
print(squares)
