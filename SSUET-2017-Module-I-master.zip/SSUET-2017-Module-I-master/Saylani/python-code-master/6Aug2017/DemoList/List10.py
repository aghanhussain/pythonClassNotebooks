players = ['charles', 'martina', 'michael',
           'florence', 'eli',"asdf",
           "asdfa","asdfadf","astest"]
fewPlayers = players[:]
print(fewPlayers)
print(players)