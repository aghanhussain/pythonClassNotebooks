requested_toppings = ['mushrooms', 'onions', 'pineapple']

print('moshrooms' in requested_toppings)

if 'mushrooms' in requested_toppings:
    print("Ok Sir")
else :
    print("Sorry, not available Sir ")
