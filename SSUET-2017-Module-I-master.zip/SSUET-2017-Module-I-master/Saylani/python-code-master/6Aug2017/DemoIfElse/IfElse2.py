marks = 95

if marks > 80:
    print("A+")
elif marks >70:
    print("A")
elif marks >60:
    print("B")
elif marks > 50:
    print("C")
elif marks > 40:
    print("D")
else:
    print("Failed")

