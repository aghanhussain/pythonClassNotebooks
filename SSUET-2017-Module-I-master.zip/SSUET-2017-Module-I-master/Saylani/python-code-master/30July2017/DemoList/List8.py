cars = ['bmw', 'audi', 'toyota', 'subaru']
print(cars)
#sortedList = sorted(cars)
sortedList = cars.sort()
print(cars)
print(sortedList)
