motorcycles = ['honda', 'yamaha', 'suzuki']
removedMotorCycles = []
print(motorcycles)

removedMotorCycles.append(motorcycles.pop())

print(motorcycles)
print(removedMotorCycles)

removedMotorCycles.append(motorcycles.pop())
print(motorcycles)
print(removedMotorCycles)
