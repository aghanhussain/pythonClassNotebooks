motorcycles = ['honda', 'yamaha', 'suzuki']
removedMotorCycles = []
print(motorcycles)

a1 = motorcycles.remove("yamaha")
print(motorcycles)
print(a1)