bicycles = ['trek', 'cannondale',
            'redline', 'specialized']
print(bicycles)
print(bicycles[0])
singleBicycle = bicycles[2]
print(singleBicycle.upper())
print(bicycles)
print(bicycles[-3])