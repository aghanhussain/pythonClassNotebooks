motorcycles = ['honda', 'yamaha', 'suzuki']
removedMotorCycles = []
print(motorcycles)

a1 = motorcycles.pop()
removedMotorCycles.append(a1)
print(motorcycles)
print(a1)

a2 = motorcycles.pop()
removedMotorCycles.append(a2)
print(motorcycles)
print(a2)