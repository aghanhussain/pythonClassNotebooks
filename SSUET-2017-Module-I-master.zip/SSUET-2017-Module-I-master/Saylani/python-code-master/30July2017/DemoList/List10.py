cars = ['bmw', 'audi', 'toyota', 'subaru',"abc"]
print(cars)

count = len(cars)
print(count)
print(cars[-1])
print(cars[-10])