motorcycles = ['honda', 'yamaha', 'suzuki']
print(motorcycles)

#motorcycles[0] = 'ducati'
motorcycles.append('ducati')
print(motorcycles)

motorcycles.insert(1,"hero")
print(motorcycles)

#motorcycles[5] = "Hello world"
motorcycles.insert(5,"Hello World")
print(motorcycles)

del motorcycles[1];
print(motorcycles)

