cars = ['bmw', 'audi', 'toyota', 'subaru']
twoCars = cars[0] + " " +cars[1]
print(twoCars)

print(cars)
cars.reverse()
print(cars)