names = ["Wajid","Ali","Qasim","Zeeshan"]
for value in range(len(names)-1,-1,-1):
    print(value)
    print(names[value])