for value in range(1,10):
    abc = 34
    print("Hello", value)

print("New", value)
print("New2", abc)