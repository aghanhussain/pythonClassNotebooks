for value in range(1,15):
    print(value)

for value in range(1,10,2):
    print(value)
print("---")
for value in range(100,0,-5):

    print(value)