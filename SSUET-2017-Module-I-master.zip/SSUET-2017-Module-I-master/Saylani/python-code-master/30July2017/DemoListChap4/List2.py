names = ["Wajid","Ali","Qasim","Zeeshan"]

for a in names:
    print("Hello world",a)
    print("New line testing")

print("Working")