magicians = ['alice', 'david', 'carolina']

for magician in magicians:
    print("Hello Mr. ",magician)
    print(magician)
print("Hello ")