names = ["Wajid","Ali","Qasim","Zeeshan"]
for value in range(0,len(names)):
    print(value)
    print(names[value])