
mylist = range(1,10)
print(mylist)
mylist2 = list(range(1,5));
print(mylist2)

mylist3 = list(range(1,20,3));
print(mylist3)