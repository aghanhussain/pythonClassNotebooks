print("First")
a = 5
b = 0
d = []
try:
    c = a/b
    e = d[5]
except:
    print("Handle Error")
else:
    print(c)

print("last")

