print("First")
a = 5
b = 0
try:
    c = a/b
except ZeroDivisionError:
    pass
else:
    print(c)

print("last")

