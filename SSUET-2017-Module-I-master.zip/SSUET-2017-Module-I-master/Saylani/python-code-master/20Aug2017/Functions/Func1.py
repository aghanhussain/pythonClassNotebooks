def greet_user():
    print("Hello World")
    print("Hello World 2")

greet_user()