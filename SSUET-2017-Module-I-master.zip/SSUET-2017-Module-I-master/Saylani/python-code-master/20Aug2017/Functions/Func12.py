def fayyaz(*itemList):
    #itemList[0] = "Pulaoo"
    for i in itemList:
        print("Buying "+i)

fayyaz("Briyani","Anday wala burger","Nihari","Lassi")
#print(myItems)