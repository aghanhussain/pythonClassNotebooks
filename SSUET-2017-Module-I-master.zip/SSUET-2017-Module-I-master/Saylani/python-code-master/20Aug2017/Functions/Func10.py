def fayyaz(itemList):
    for i in itemList:
        print("Buying "+i)

myItems = ["Briyani","Anday wala burger","Nihari","Lassi"]
fayyaz(myItems)