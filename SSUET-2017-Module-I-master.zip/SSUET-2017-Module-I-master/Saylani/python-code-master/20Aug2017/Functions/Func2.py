def fayyaz():
    print("Make Tea")
    print("Add sugar 2 spoon")
    print("Add 1 Tea bag")
    print("Fill cup")

fayyaz()
fayyaz()
fayyaz()
fayyaz()