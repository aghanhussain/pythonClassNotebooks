def fayyaz(**itemList):
    #itemList[0] = "Pulaoo"
    for i,j in itemList.items():
        print("Buying "+i)
        print(j)


fayyaz(rice=2,coke=5)
#print(myItems)