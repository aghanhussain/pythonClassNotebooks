def fayyaz(noOfCups, sugar):
    print("Make Tea")
    print("Preparing "+str(noOfCups)+" cups of Tea")
    print("Adding sugar "+str(sugar)+" spoon")
    print("Add 1 Tea bag")
    print("Fill cup")

fayyaz(2,sugar=3)