def fayyaz(noOfCups, sugar=2):
    print("Make Tea")
    print("Preparing "+str(noOfCups)+" cups of Tea")
    print("Adding sugar "+str(sugar)+" spoon")
    print("Add 1 Tea bag")
    print("Fill cup")

fayyaz(4)
fayyaz(4,3)
fayyaz(4,sugar=3)
fayyaz(sugar=3,noOfCups=3)
fayyaz(noOfCups=3)