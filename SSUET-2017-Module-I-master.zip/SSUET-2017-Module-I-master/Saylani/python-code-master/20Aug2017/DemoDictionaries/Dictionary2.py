stu1 = {'name':'Qasim',
        'email':'abc@gmail.com',
        'age':20,
        23:"hello",
        True:"working",
        2.5:"new",
        4:True}
print(stu1)
print(stu1['name'])
print(stu1['age'])
print(stu1[23])
print(stu1[4])