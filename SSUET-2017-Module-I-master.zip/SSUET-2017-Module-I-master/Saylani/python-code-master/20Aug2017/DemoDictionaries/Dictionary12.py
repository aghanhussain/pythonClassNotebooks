stu1 = {
    'name':'Qasim',
    'email':'qasim@gmail.com',
    'languages' : ['C#','Python','JavaScript']
}
stu2 = {'name':'Inzamam','email':'inzamam@gmail.com',
        'languages': ['C#', 'Java', 'JavaScript']
}
stu3 = {'name':'Jaffar','email':'jaffar@gmail.com',
        'languages': ['C#', 'Python', 'PHP']
}

studentDictionary = {}
studentDictionary['Stu1'] = stu1
studentDictionary['Stu2'] = stu2
studentDictionary['Stu3'] = stu3

