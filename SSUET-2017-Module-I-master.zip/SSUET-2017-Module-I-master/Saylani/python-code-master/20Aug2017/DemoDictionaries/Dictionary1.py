stu1 = {'name':'Qasim',
        'email':'abc@gmail.com',
        'age':20}
print(stu1)
print(stu1['name'])
print(stu1['age'])