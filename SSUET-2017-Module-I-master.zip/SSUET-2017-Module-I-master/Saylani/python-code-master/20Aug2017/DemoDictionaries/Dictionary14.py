'''
Global dictonary
1) cmp(dic1, dict2)
2) len(dic)
3) str(dic)
4) type(varible)

Class function

1) dic.clear()
2) dic.copy()
3) dict.fromkeys()
4) dic.get(key, defualt=None)
5) dic.has_key(key)
6) dic.items()
7) dic.keys()
8) dic.values()
9) dic.setdefualt(key, defualt=None)
10) dic.update(dic2)
'''

student ={"name":"Asif","age":20}
print(student)
#student.clear()
#print(student)
print(student.fromkeys())
