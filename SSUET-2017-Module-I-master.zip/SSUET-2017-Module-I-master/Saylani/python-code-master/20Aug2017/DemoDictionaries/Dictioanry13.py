studentDictionary = {
'stu1' : {
    'name':'Qasim',
    'email':'qasim@gmail.com',
    'languages' : ['C#','Python','JavaScript']
},
'stu2' : {'name':'Inzamam','email':'inzamam@gmail.com',
        'languages': ['C#', 'Java', 'JavaScript']
},
'stu3' : {'name':'Jaffar','email':'jaffar@gmail.com',
        'languages': ['C#', 'Python', 'PHP']
}
}

