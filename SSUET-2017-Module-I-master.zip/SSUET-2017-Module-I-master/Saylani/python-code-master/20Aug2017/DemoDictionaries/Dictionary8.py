a={"Qasim","Zeeshan","Zeeshan"}
print(a)