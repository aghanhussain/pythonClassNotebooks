stu1 = {'name':'Qasim','email':'qasim@gmail.com'}
stu2 = {'name':'Inzamam','email':'inzamam@gmail.com'}
stu3 = {'name':'Jaffar','email':'jaffar@gmail.com'}

students = [stu1,stu2,stu3]
students = []
students.append(stu1)
students.append(stu2)
students.append(stu3)