firstName = "Qasim"
lastName = "M. Aslam"
age = 45

fullName = firstName +" "+ lastName
print(firstName)
print(lastName)
print(fullName)
print(firstName,lastName)

fullName1 = firstName + " " + lastName +" " +str(age)
print(fullName1)

