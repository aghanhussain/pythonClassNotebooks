num1 = 0.1
num2 = 0.2
print(num1 + num2)
print(num1 - num2)
print(num1 * num2)
num3 = 5
#print(num3)
