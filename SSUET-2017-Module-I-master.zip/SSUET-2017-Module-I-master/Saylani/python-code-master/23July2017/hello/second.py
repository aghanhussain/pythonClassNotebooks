name = "qasim"
name1 = name.title()
print(name)
print(name1)
print(name.title())
print(name.upper())
print(name.lower())
print(name)