name = " hello world  "
name = name.strip()
name = name.title()

name1 = name.strip()
name2 = name1.title()
print(name2)

