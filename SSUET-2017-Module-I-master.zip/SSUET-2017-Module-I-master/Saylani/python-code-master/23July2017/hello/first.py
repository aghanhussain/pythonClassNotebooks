print("Hello New world")

name = "Mughal"
name = 'Mughal'
age = 45
email = "zeeshanhanif@gmail.com"
print(name)
name = 67
print(name)

name1 = "My father\"s name is M. Aslam"
print(name1)


