name = " hello world  "
print(name.strip().title())