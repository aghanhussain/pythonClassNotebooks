num1 = 81
num2 = 3

print(num1 + num2)
print(num1 - num2)
print(num1 / num2)
print(num1 * num2)
print(num1 % num2)
print(num1 ** num2)
print(num1 // num2)


num3 = 5 - 3 * 2 + 2 / 2
print(num3)