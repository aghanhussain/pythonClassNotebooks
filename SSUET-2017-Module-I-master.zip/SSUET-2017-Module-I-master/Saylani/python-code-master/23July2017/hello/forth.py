languages = "Languages:\n\tPython\n\tC\n\tJavaScript"
print(languages)

name = "  Hello World  "
print(name)
print(name.rstrip())
print(name.lstrip())
print(name.strip())
print(name)