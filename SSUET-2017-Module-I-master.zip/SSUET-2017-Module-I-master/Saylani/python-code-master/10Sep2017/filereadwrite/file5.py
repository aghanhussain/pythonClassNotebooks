
with open('demo1.txt','w') as fileObj:
    fileObj.write("I love programming!")