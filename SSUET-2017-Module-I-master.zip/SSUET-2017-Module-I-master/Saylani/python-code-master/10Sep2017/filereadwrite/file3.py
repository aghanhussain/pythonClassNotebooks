with open('demo.txt') as fileObj:
    lines = fileObj.readlines()
    print(lines)