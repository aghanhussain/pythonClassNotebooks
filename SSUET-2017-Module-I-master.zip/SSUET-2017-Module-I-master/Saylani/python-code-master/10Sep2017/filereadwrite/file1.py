with open('demo.txt') as fileObj:
    content = fileObj.read()
    print(content)