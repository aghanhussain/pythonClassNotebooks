from car import Car
from electricalcar import ElectricCar

c = Car('audi', 'a4', 2016, b)