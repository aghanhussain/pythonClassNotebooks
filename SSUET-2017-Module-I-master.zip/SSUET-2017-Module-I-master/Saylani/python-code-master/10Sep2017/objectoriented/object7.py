from car import Car as c

import electricalcar as ect

abc = c('audi', 'a4', 2016)
e = ect.ElectricCar()
